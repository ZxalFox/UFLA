INFORMAÇÕES GERAIS

Nome do jogo: Ghostly Nights

Integrantes do grupo:
- Alexandre Moraes
- Gabriel Andrade
- Ayron
- Douglas

GAMEPLAY

Número de classes de atores com ação: 
BarraDaUlt, BarraDeExperiencia, BarraDeHp, BolaDeFogo, Inimigo, Player, Ult

Número de classes de mundo: 
StartScreen, MeuMundo, Instruções, Placar

Qual classe que não é ator nem mundo?
Som

Número de arquivos de áudio usados:
bolaDeFogo.mp3, enemyDeath.mp3, heartPickupSound.mp3, menuMusic.mp3, music.mp3, pegarEsmeraldaSom3.mp3

Permite várias partidas no próprio gameplay?
Sim

Tem tela inicial?
Sim

Tem tela de histórico de pontuação?
Sim

REQUISITOS DE OO

Atende aos requisitos de OO da primeira entrega?
SIm

Tem alta coesão?
Sim

Tem baixo acoplamento?
Sim

Usa design baseado em responsabilidade?
Sim

Tem acoplamento implícito?
Não

Tem replicação de código?
Não

Tem duas superclasses com subclasses com implementação útil?
Sim

COMENTÁRIOS (OPCIONAIS)

Algum comentário sobre o tema do trabalho?


Algum comentário sobre o Greenfoot?


