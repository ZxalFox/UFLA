import greenfoot.*;

/**
 * Classe referente ao coração, objeto que ao interagir com o player aumenta sua vida.
 * 
 * @authors Gabriel Carvalho, Alexandre Carvalhaes, Douglas Slves, Ayron Sanfra. 
 * @version Marca 20.0
 */
public class Heart extends Actor
{
}
