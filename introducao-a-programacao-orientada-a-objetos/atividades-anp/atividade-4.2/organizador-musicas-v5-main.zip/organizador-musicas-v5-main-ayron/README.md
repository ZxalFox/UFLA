# Projeto `organizador-musicas-v5`

Um projeto para colecionar arquivos de áudio.

Autores: David Barnes e Michael Kölling

- Traduzido por: Julio César Alves

```
   Objects First with Java - A Practical Introduction using BlueJ
   6ª edição
   David J. Barnes e Michael Kölling
   Pearson Education, 2016
```

É discutido no capítulo 4.

Para começar:

Crie um objeto `OrganizadorDeMusicas`.

Ele busca, automaticamente, músicas com extensão .mp3 que estejam na mesma pasta.
