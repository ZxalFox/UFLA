# Projeto `casa`

Autores: Michael Kölling and David J. Barnes

- Traduzido do original `house` por: Julio César Alves

Este projeto é parte do material do livro

```
   Objects First with Java - A Practical Introduction using BlueJ
   6ª edição
   David J. Barnes e Michael Kölling
   Pearson Education, 2017
```

É discutido no capítulo 1.

Este é um projeto muito simples para demonstrar algumas características
dos objetos
    
Este projeto é geralmente usado depois de estudar o projeto `formas`.
Ele tem uma classe a mais que o projeto `formas`. Esta classe (chamada
`Figura`) usa as formas para desenhar uma figura. Ela pode ser usada
para experimentação de alterações no código-fonte.
