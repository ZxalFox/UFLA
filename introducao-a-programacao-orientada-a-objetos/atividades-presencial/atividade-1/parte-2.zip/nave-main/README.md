# Projeto `nave`

Esse projeto foi criado para ser usada em aula prática de disciplinas de 
Programação Orientada a Objetos, do Departamento de Computação Aplicada da
Universidade Federal de Lavras (DCC/UFLA).

Autor: Julio César Alves
- Professor DAC/ICET/UFLA
- juliocesar.alves[at]ufla.br

Projeto original criado em: 2015/09/15

## Instruções:

Ver roteiro de aulas preparado pelo professor.

