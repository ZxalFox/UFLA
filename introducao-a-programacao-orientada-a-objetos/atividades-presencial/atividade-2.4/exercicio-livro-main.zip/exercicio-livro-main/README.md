# Projeto `Exercicio-Livro`

Autores: David Barnes and Michael Kölling

- Traduzido por: Julio César Alves

Este projeto é parte do material do livro

```
   Objects First with Java - A Practical Introduction using BlueJ
   Sixth edition
   David J. Barnes and Michael Kölling
   Pearson Education, 2016
```

É discutido no capítulo 2.

## Objetivo do projeto

Este projeto tem o código inicial para um conjunto de exercícios do Capítulo 2.

## Instruções para o usuário

Complete os exercícios do Capítulo 2.
