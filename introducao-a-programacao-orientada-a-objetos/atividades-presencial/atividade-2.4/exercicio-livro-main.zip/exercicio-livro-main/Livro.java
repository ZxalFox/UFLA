/**
 * Uma classe que mantém informação de um livro.
 * Ela pode ser parte de uma aplicação mair como um sistema
 * de uma biblioteca, por exemplo.
 *
 * @author (Ayron Sanfra.)
 * @version (18/09/2023.)
 * 
 * Os objetos Livro são imutáveis?
 *  - Em relaçao ao valor dos atributos, desde que nao tenham um metodo "set" que os altera
 *  podemos dizer que sim, sao imutaveis, ja em relaçao a estrutura do objeto, a unica 
 *  maneira seria alterando via direta no codigo. 
 */
class Livro
{
    // Os atributos.
    private String autor;
    private String titulo;
    private int paginas;
    private String id;
    private int numeroEmprestimos;

    /**
     * Define os atributos autor e o título quando este
     * objeto é criado.
     */
    public Livro(String autorLivro, String tituloLivro, int numeroPaginas)
    {
        autor = autorLivro;
        titulo = tituloLivro;
        paginas = numeroPaginas;
        id = "";
        numeroEmprestimos = 0;
    }

    public void imprimirAutor (){
        System.out.println(autor);
    }

    public void imprimirTitulo (){
        System.out.println(titulo);
    }

    public int obterPaginas (){
        return paginas;
    }

    public String obterId (){
        return id;
    }

    public void emprestar (){
        numeroEmprestimos += 1;
    }

    public int obterEmprestimos(){
        return numeroEmprestimos;
    }

    public String alterarId(String novoId){
        if(novoId.length() <3){
            return "Erro: o numero de chamada inserido possui menos de 3 caracteres";
        }else{
            id = novoId;
            return "Numero de chamada alterado com sucesso!";
        }
    }

    public void imprimirDetalhes (){
        System.out.println("-------------------------");
        System.out.println("Titulo: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println(paginas + " paginas");
        if (id.length() == 0){
            System.out.println("Numero de chamada: NDEF"); 
        }else{
            System.out.println("Numero de chamada: " + id);
        }
        System.out.println("Emprestado " + numeroEmprestimos + " vezes");
        System.out.println("-------------------------");
    }
}
