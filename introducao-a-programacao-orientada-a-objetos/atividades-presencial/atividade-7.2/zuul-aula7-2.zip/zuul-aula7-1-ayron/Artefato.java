
/**
 * Escreva uma descrição da classe Artefato aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Artefato
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private String nome;
    private String descricao;

    /**
     * Construtor para objetos da classe Artefatos
     */
    public Artefato(String nome, String descricao)
    {
        this.nome = nome;
        this.descricao = descricao;
    }

    /**
     * Um exemplo de um método - substitua este comentário pelo seu próprio
     * 
     * @param  y   um exemplo de um parâmetro de método
     * @return     a soma de x e y 
     */
    public String obterNome()
    {
        // escreva seu código aqui
        return nome;
    }
    
    public String obterDescricao()
    {
        // escreva seu código aqui
        return descricao;
    }
    
    public void alterarNome(String novoNome){
        nome = novoNome;
    }
    
    public void alterarDescricao(String novaDescricao){
        descricao = novaDescricao;
    }
}
