/**
 *  Essa eh a classe principal da aplicacao "World of Zull".
 *  "World of Zuul" eh um jogo de aventura muito simples, baseado em texto.
 *  Usuarios podem caminhar em um cenario. E eh tudo! Ele realmente
 *  precisa ser estendido para fazer algo interessante!
 * 
 *  Para jogar esse jogo, crie uma instancia dessa classe e chame o metodo
 *  "jogar".
 * 
 *  Essa classe principal cria e inicializa todas as outras: ela cria os
 *  locais, cria o analisador e comeca o jogo. Ela tambeme avalia e 
 *  executa os comandos que o analisador retorna.
 * 
 * Traduzido por Julio César Alves. Versão: 2023.10.21
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class Jogo 
{
    private Analisador analisador;
    private Local localAtual;
        
    /**
     * Cria o jogo e incializa seu mapa interno.
     */
    public Jogo() 
    {
        criarLocais();
        analisador = new Analisador();
    }

    /**
     * Cria todos os locais e liga as saidas deles
     */
    private void criarLocais()
    {
        Local casa, celeiro, plantacao, curral, bosque, riacho, galpao;  
        // cria os locais
        casa = new Local("dentro da casa da fazenda");
        celeiro = new Local("no celeiro");
        plantacao = new Local("em uma plantação de café");
        curral = new Local("no curral da fazenda");
        bosque = new Local("no bosque sombrio", "Pena de corvo", "uma pena de corvo preta com uma marca branca");
        riacho = new Local("na beira do riacho");
        galpao = new Local("no galpão de máquinas da fazenda", "Lanterna", "uma lanterna de metal azul que emite uma luz amarela");
        
        // inicializa as saidas dos locais
        casa.ajustarSaida("leste", celeiro);
        casa.ajustarSaida("sul", curral);
        casa.ajustarSaida("oeste", galpao);
        
        celeiro.ajustarSaida("oeste", casa);
        
        galpao.ajustarSaida("leste", casa);
        
        curral.ajustarSaida("norte", casa);
        curral.ajustarSaida("leste", plantacao);
        
        plantacao.ajustarSaida("oeste", curral);
        plantacao.ajustarSaida("sul", bosque);
        
        bosque.ajustarSaida("norte", plantacao);
        bosque.ajustarSaida("sul", riacho);
        
        riacho.ajustarSaida("norte", bosque);

        localAtual = casa;  // o jogo comeca dentro da casa
    }

    /**
     *  Rotina principal do jogo. Fica em loop ate terminar o jogo.
     */
    public void jogar() 
    {            
        imprimirBoasVindas();

        // Entra no loop de comando principal. Aqui nos repetidamente lemos
        // comandos e os executamos ate o jogo terminar.
                
        boolean terminado = false;
        while (! terminado) {
            Comando comando = analisador.obterComando();
            terminado = processarComando(comando);
        }
        System.out.println("Obrigado por jogar. Ate mais!");
    }

    /**
     * Imprime a mensagem de abertura para o jogador.
     */
    private void imprimirBoasVindas()
    {
        System.out.println();
        System.out.println("--------------------------------------------------");
        System.out.println("                ISABELLAS'S DREAM                 ");
        System.out.println("--------------------------------------------------");
        System.out.println("Isabella é uma garota que possui um sono muito profundo,");
        System.out.println("você deve ajudar ela em uma jornada pelo mundo dos sonhos para que ela consiga acordar");
        System.out.println("Digite 'ajuda' se voce precisar de ajuda.");
        System.out.println();
        
        localAtual.obterDescricaoLonga();
    }

    /**
     * Dado um comando, processa (executa) o comando.
     * @param comando O Comando a ser processado.
     * @return true se o comando finaliza o jogo.
     */
    private boolean processarComando(Comando comando) 
    {
        boolean querSair = false;

        if(comando.ehDesconhecido()) {
            System.out.println("Eu nao entendi o que voce disse...");
            return false;
        }

        String palavraDeComando = comando.obterPalavraDeComando();
        if (palavraDeComando.equals("ajuda")) {
            imprimirAjuda();
        }
        else if (palavraDeComando.equals("ir")) {
            irParaLocal(comando);
        }
        else if (palavraDeComando.equals("sair")) {
            querSair = sair(comando);
        }
        else if (palavraDeComando.equals("observar")){
            observar(comando);
        }

        return querSair;
    }
    
    private void observar(Comando comando){
        if (comando.temSegundaPalavra()){
            System.out.println("Nao e possivel observar coisas especificas");
            return;
        }
        localAtual.obterDescricaoLonga();
    }

    // Implementacoes dos comandos do usuario

    /**
     * Imprime informacoes de ajuda.
     * Aqui nos imprimimos algo bobo e enigmatico e a lista de 
     * palavras de comando
     */
    private void imprimirAjuda() 
    {
        System.out.println("Voce esta perdido. Voce esta sozinho. Voce caminha");
        System.out.println("por uma fazenda.");
        System.out.println();
        System.out.println("Suas palavras de comando sao:");
        System.out.println(analisador.exibirPalavrasDeComando());
    }

    /** 
     * Tenta ir em uma direcao. Se existe uma saida entra no 
     * novo local, caso contrario imprime mensagem de erro.
     */
    private void irParaLocal(Comando comando) 
    {
        if(!comando.temSegundaPalavra()) {
            // se nao ha segunda palavra, nao sabemos pra onde ir...
            System.out.println("Ir pra onde?");
            return;
        }

        String direcao = comando.obterSegundaPalavra();

        // Tenta sair do local atual
        Local proximoLocal = null;
        proximoLocal = localAtual.obterSaida(direcao);

        if (proximoLocal == null) {
            System.out.println("Nao ha passagem!");
        }
        else {
            localAtual = proximoLocal;
            
            localAtual.obterDescricao();
        }
    }
    

    /** 
     * "Sair" foi digitado. Verifica o resto do comando pra ver
     * se nos queremos realmente sair do jogo.
     * @return true, se este comando sai do jogo, false, caso contrario
     */
    private boolean sair(Comando comando) 
    {
        if(comando.temSegundaPalavra()) {
            System.out.println("Sair o que?");
            return false;
        }
        else {
            return true;  // sinaliza que nos queremos sair
        }
    }
}
