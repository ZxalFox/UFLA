# Projeto `Máquina de Ingressos Ingênua`

Autores: David Barnes and Michael Kölling

- Traduzido por: Julio César Alves

Este projeto é parte do material do livro:

```
   Objects First with Java - A Practical Introduction using BlueJ
   Sixth edition
   David J. Barnes and Michael Kölling
   Pearson Education, 2016
```

É discutido no capítulo 2.

## Objetivo do projeto

Ilustrar o básico de atributos, construtores e métodos.

## Como inicar o projeto

Crie um ou mais objetos `MaquinaIngressos`.
