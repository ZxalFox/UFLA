/**
 * Escreva uma descrição da classe FeedDeNoticias aqui.
 * 
 * @author ayron-sanfra
 * @version 1.0
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class FeedDeNoticias {

    private List<MensagemTexto> mensagensTexto;
    private List<MensagemFoto> mensagensFoto;
    private Map<Integer, Mensagem> mensagensMap; // Mapa para mapear ID para Mensagem

    private int idCounter; // Contador para gerar IDs únicos

    public FeedDeNoticias() {
        this.mensagensTexto = new ArrayList<>();
        this.mensagensFoto = new ArrayList<>();
        this.mensagensMap = new HashMap<>();
        this.idCounter = 1; // Inicia o contador em 1
    }

    public void postarMensagemTexto(String autor, String texto) {
        MensagemTexto mensagemTexto = new MensagemTexto(idCounter, autor, texto);
        mensagensTexto.add(mensagemTexto);
        mensagensMap.put(idCounter, mensagemTexto);
        idCounter++;
    }

    public void postarMensagemFoto(String autor, String nomeArquivo, String legenda) {
        MensagemFoto mensagemFoto = new MensagemFoto(idCounter, autor, nomeArquivo, legenda);
        mensagensFoto.add(mensagemFoto);
        mensagensMap.put(idCounter, mensagemFoto);
        idCounter++;
    }

    public void curtirMensagem(int mensagemId, String usuario) {
        Mensagem mensagem = mensagensMap.get(mensagemId);
        if (mensagem != null) {
            mensagem.curtir(usuario);
        } else {
            System.out.println("Mensagem não encontrada.");
        }
    }

    public void comentarMensagem(int mensagemId, String usuario, String comentario) {
        Mensagem mensagem = mensagensMap.get(mensagemId);
        if (mensagem != null) {
            mensagem.adicionarComentario(usuario, comentario);
        } else {
            System.out.println("Mensagem não encontrada.");
        }
    }

    public void exibirFeed() {
        System.out.println("Feed de Notícias:");

        for (MensagemTexto mensagemTexto : mensagensTexto) {
            System.out.println(mensagemTexto.getMensagemCompleta());
        }

        for (MensagemFoto mensagemFoto : mensagensFoto) {
            System.out.println(mensagemFoto.getMensagemCompleta());
        }
    }

    public static void main(String[] args) {
        FeedDeNoticias feed = new FeedDeNoticias();

        feed.postarMensagemTexto("Tião", "Cruzeiro Campeão!");
        feed.postarMensagemTexto("Tia Maria", "Bom dia, pessoal!");

        feed.postarMensagemFoto("Tião", "cruzeiro.jpg", "Dia de comemoração!");
        feed.postarMensagemFoto("Tia Maria", "amanhecer.jpg", "Que vista maravilhosa!");

        feed.exibirFeed();

        // Exemplo de curtir e comentar
        feed.curtirMensagem(1, "Alice");
        feed.comentarMensagem(1, "Bob", "Parabéns!");
        feed.exibirFeed();
    }
}

