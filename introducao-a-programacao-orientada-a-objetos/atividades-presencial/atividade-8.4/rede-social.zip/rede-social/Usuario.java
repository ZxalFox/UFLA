/**
 * Escreva uma descrição da classe Usuario aqui.
 * 
 * @author ayron-sanfra
 * @version 1.0
 */
class Usuario {

    private String nome;

    public Usuario(String nome) {
        this.nome = nome;
    }
}
