
/**
 * Escreva uma descrição da classe Mensagem aqui.
 * 
 * @author ayron-sanfra
 * @version 1.0 
 */

import java.util.Date;
import java.util.List;
import java.util.ArrayList;

 class Mensagem {

    private int id;
    private String autor;
    private long timestamp;
    private int quantidadeCurtidas;
    private List<String> comentarios;

    public Mensagem(int id, String autor) {
        this.id = id;
        this.autor = autor;
        this.timestamp = System.currentTimeMillis();
        this.quantidadeCurtidas = 0;
        this.comentarios = new ArrayList<>();
    }

    public void curtir(String usuario) {
        quantidadeCurtidas++;
    }

    public void adicionarComentario(String usuario, String comentario) {
        comentarios.add(comentario);
    }

    public String getAutor() {
        return autor;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public int getQuantidadeCurtidas() {
        return quantidadeCurtidas;
    }

    public List<String> getComentarios() {
        return comentarios;
    }
}
