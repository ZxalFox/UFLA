
/**
 * Escreva uma descrição da classe MensagemTexto aqui.
 * 
 * @author ayron-sanfra
 * @version 1.0
 */

import java.text.SimpleDateFormat;

public class MensagemFoto extends Mensagem {

    private String nomeArquivo;
    private String legenda;

    public MensagemFoto(int id, String autor, String nomeArquivo, String legenda) {
        super(id, autor);
        this.nomeArquivo = nomeArquivo;
        this.legenda = legenda;
    }

    public String getNomeArquivo() {
        return nomeArquivo;
    }

    public String getLegenda() {
        return legenda;
    }

    private String getTextoTempo() {
        long tempoAtual = System.currentTimeMillis();
        long diferenca = (tempoAtual - getTimestamp());
        long diferencaSeg = diferenca / 1000;
        long diferencaMin = diferencaSeg / 60;
        if (diferencaMin < 1) {
            return "Há " + diferencaSeg + " segundos";
        } else {
            return "Há " + diferencaMin + " minutos";
        }
    }

    public String getMensagemCompleta() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        StringBuilder mensagemCompleta = new StringBuilder();
        mensagemCompleta.append(getAutor()).append(" escreveu: ").append(getNomeArquivo())
                .append(" <legenda: ").append(getLegenda()).append(">")
                .append("\n    ").append(getTextoTempo())
                .append("\n    ").append(getQuantidadeCurtidas()).append(" pessoa(s) curtiram isso!")
                .append("\n    Não há comentários.");
        return mensagemCompleta.toString();
    }
}
