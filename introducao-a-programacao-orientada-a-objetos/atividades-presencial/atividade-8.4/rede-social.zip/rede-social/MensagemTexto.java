
/**
 * Escreva uma descrição da classe MensagemTexto aqui.
 * 
 * @author ayron-sanfra
 * @version 1.0
 */

import java.text.SimpleDateFormat;

public class MensagemTexto extends Mensagem {

    private String texto;

    public MensagemTexto(int id, String autor, String texto) {
        super(id, autor);
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }

    private String getTextoTempo() {
        long tempoAtual = System.currentTimeMillis();
        long diferenca = (tempoAtual - getTimestamp());
        long diferencaSeg = diferenca / 1000;
        long diferencaMin = diferencaSeg / 60;
        if (diferencaMin < 1) {
            return "Há " + diferencaSeg + " segundos";
        } else {
            return "Há " + diferencaMin + " minutos";
        }
    }

    public String getMensagemCompleta() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        StringBuilder mensagemCompleta = new StringBuilder();
        mensagemCompleta.append(getAutor()).append(" escreveu: ").append(getTexto())
                .append("\n    ").append(getTextoTempo())
                .append("\n    ").append(getQuantidadeCurtidas()).append(" pessoa(s) curtiram isso!")
                .append("\n    Comentários:");
        for (String comentario : getComentarios()) {
            mensagemCompleta.append("\n        ").append(comentario);
        }
        return mensagemCompleta.toString();
    }
}
